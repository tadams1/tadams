var config = require('./config.global');
 
module.exports = config;